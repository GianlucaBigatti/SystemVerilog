add wave -label X sim:/tb_ula/x
add wave -label Y sim:/tb_ula/y
add wave -label SORT sim:/tb_ula/sort

add wave -label OUT sim:/tb_ula/out

run 500ns