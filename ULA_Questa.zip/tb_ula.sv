`timescale 1ns/1ns

module tb_ula;

    parameter WIDTH = 8;

    logic [WIDTH-1:0] x, y;
    logic [2:0]       sort;
    logic [WIDTH-1:0] out;

    ULA #(WIDTH) dut (
        .x(x),
        .y(y),
        .sort(sort),
        .out(out)        
    );

    /*
    SORT LIST
        3'd1 = and
        3'd2 = xor
        3'd3 = add
        3'd4 = sub
        3'd5 = not
        3'd6 = or
    */
    initial begin
        //AND
        x = 8'd10; y = 8'd12; sort = 3'd1;
        #10;
        $display("AND: %d", out);
        assert (out == 8'b1000)
            else   $error("AND, error");

        //XOR
        sort = 3'd2;
        #10;
        $display("XOR: %d", out);
        assert (out == 8'b0110)
            else   $error("XOR, error");

        //ADD
        sort = 3'd3;
        #10;
        $display("ADD: %d", out);
        
        //SUB - Complemento de 2
        sort = 3'd4;
        #10;
        $display("SUB: %d", out);

        //NOT
        sort = 3'd5;
        #10;
        $display("NOT: %d", out);
        assert (out == 8'b11110101)
            else   $error("NOT, error");

        //OR
        sort = 3'd6;
        #10;
        $display("OR: %d", out);
        assert (out == 8'b1110)
            else   $error("OR, error");     
    end

endmodule