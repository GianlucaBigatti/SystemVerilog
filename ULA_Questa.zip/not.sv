module NOT #(parameter WIDTH = 8) (
    input logic     [WIDTH-1:0]   x,
    output logic    [WIDTH-1:0]   out
);
    assign out = ~x;

endmodule