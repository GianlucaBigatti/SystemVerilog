module ULA #(parameter WIDTH = 8) (
    input   logic   [WIDTH-1:0] x, y,
    input   logic   [2:0]       sort,
    output  logic   [WIDTH-1:0] out
);

    logic [WIDTH-1:0] not_out, and_out, or_out, xor_out, add_out, sub_out;

    AND #(WIDTH) uand (.x(x), .y(y), .out(and_out));
    XOR #(WIDTH) uxor (.x(x), .y(y), .out(xor_out));
    ADD #(WIDTH) uadd (.x(x), .y(y), .out(add_out));
    SUB #(WIDTH) usub (.x(x), .y(y), .out(sub_out));
    OR  #(WIDTH) uor  (.x(x), .y(y), .out(or_out));
    NOT #(WIDTH) unot (.x(x), .out(not_out));

    always_comb begin : ula_choice
        case(sort)
            3'b001: out = and_out;
            3'b010: out = xor_out;
            3'b011: out = add_out;
            3'b100: out = sub_out;
            3'b101: out = not_out;
            3'b110: out = or_out;

            default: out = '0;          //'0 muda tudo
        endcase
    end

endmodule