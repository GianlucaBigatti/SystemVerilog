if {[file isdirectory work]} {vdel -all -lib work}
vlib work
vmap work work

set TOP_ENTITY {work.tb_ula}

vlog -work work and.sv
vlog -work work xor.sv
vlog -work work add.sv
vlog -work work sub.sv
vlog -work work not.sv
vlog -work work or.sv
vlog -work work ula.sv
vlog -work work tb_ula.sv

vsim -voptargs=+acc ${TOP_ENTITY}

quietly set StdArithNoWarnings 1
quietly set StdVitalGlitchNoWarnings 1

do wave.do
run 500ns