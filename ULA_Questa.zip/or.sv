module OR #(parameter WIDTH = 8) (
    input logic     [WIDTH-1:0]   x, y,
    output logic    [WIDTH-1:0]   out
);
    assign out = x | y;

endmodule