// device: xc7a100tcsg324-1
module top_nexys_a7 #()(
    input clock,            // clock, from board
    input reset,            // reset, button n17 (middle)
    input rec,              // records switches' values, button m18 (top)
    input clear,            // clears memory, button p18 (bottom)
    input attempt,          // use the values from switches for an attempt, button p17 (middle)

    input logic [15:0] sw,   // switches, use to enter value

    output logic [15:0] led, // leds, show which switches the user set correctly
    output logic [7:0] ddp,  // displays values from switches
    output logic [7:0] an    //  
);

// display things
logic [5:0] d1, d2, d3, d4, d5, d6, d7, d8;

// memory stores the values from switches
logic [15:0] memory;

// position of matches
logic [15:0] match;

// number of matches
logic [4:0] count;



// display instance
dspl_drv_NexysA7 display(
  .clock(clock), .reset(reset),
  .d1(d1), .d2(d2), .d3(d3), .d4(d4), 
  .d5(d5), .d6(d6), .d7(d7), .d8(d8),
  .an(an), .dec_ddp(ddp)
);



// sequencial things
always @(posedge clock, negedge reset) begin
  if ( !reset ) begin
    // 1 - 1111 - 1 
    // en - val - dot
    d1 <= {1'b1, 0, 0, 0, count[4], 1'b1};
    d2 <= {1'b1, count[3], count[2], count[1], count[0], 1'b1};
    d3 <= 0;
    d4 <= 0;
    d5 <= {1'b1, sw[3], sw[2], sw[1], sw[0], 1'b1};
    d6 <= {1'b1, sw[7], sw[6], sw[5], sw[4], 1'b1};    
    d7 <= {1'b1, sw[11], sw[10], sw[9], sw[8], 1'b1};    
    d8 <= {1'b1, sw[15], sw[14], sw[13], sw[12], 1'b1};
  end else begin
    d1 <= 0;
    d2 <= 0;
    d3 <= 0;
    d4 <= 0;
    d5 <= 0;
    d6 <= 0;
    d7 <= 0;
    d8 <= 0;    
  end

  memory[15:0] <= ( clear | reset ) ? 16'b0 : ( rec ? sw[15:0] : memory[15:0] ); // deals with memory's value
end



// combinational things
always_comb begin
  match = memory & sw;
  count = $countones(match);

  // comment leds so that the position of matches doesn't show
  led   = match;
end

endmodule